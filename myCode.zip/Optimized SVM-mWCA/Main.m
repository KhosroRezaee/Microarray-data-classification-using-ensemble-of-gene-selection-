clc
clear

global m
global s
global x1
global x2

clear m s x1 x2

addpath('D:\Under Writing\Hepatitis\Code Mordade 95\Data')
addpath ('PSO Feature Selection')

NuOFe = 5;       % Desired Number of Selected Features
MaxIt = 2;      % Maximum Number of Iterations in PSO Feature Selection

load UCI_Hepatits_Database

% imputedValues = knnimpute(UCI_Hepatits_Database)
% data=knnimpute(UCI_Hepatits_Database,1,'Distance', 'seuclidean');
data=UCI_Hepatits_Database;

label=data(:,1);
label(label==2)=0;
Label=(label+1); % 2 Dead  & 1 Alive
data(:,1)=[];

for i=1:size(data,2)
    temp=data(:,i);
    ind=~isnan(temp);
    ind1=ind & logical(label);
    ind0=ind & ~logical(label);
    m1=mean(temp(ind1));
    m0=mean(temp(ind0));
    temp(logical(label) & isnan(temp))=m1;
    temp(~logical(label) & isnan(temp))=m0;
    data(:,i)=temp;
end

Input=data;
mindata = min(Input);
maxdata = max(Input);
Data = bsxfun(@rdivide,bsxfun(@minus, Input, mindata),maxdata - mindata);

%=========================Selecting best features by PSO==================== 
% disp('...............Feature selection by PSO.................')
% IndPSO = PSO_Feature_Selection (Data,Label,NuOFe,MaxIt);
% disp('....................................................................')
% 
% Data = Data(:,IndPSO);

% ------------------------------Data dividing---------------------------------
[trainX, testX] = crossvalind('HoldOut',Label,0.3);

TrainData = Data(trainX,:);
TrainLabel = Label(trainX);
TestData = Data(testX,:);
TestLabel = Label(testX);

save('Info','TrainData','TrainLabel','TestData','TestLabel')


nvars=2*size(Data,2);
PopulationSize=50;
MaxGenerations=50;
FitnessLimit=0;

c = Genetic_Algorithm...
    (nvars,PopulationSize,MaxGenerations,FitnessLimit);



m = abs(c(1));
s = abs(c(2));
% Nuoo = (c(3)^2)/((c(3)^2)+1);
% p = (c(4)^2)/((c(4)^2)+1);

x1 = abs(c(3));
x2 = abs(c(4));


Model = fitcsvm(TrainData,TrainLabel,'KernelFunction','mhlbns','Cost',[0,x1;x2,0]);

Predicted_Train_Labels_New  = predict(Model,TrainData);
NewSVMTrain = confusionmat(TrainLabel,Predicted_Train_Labels_New);
Err_MultiNewSvm_Train  = 1 - sum(diag(NewSVMTrain))/sum(NewSVMTrain(:));

Predicted_Test_Labels_New =  predict(Model,TestData);
NewSVMTest = confusionmat(TestLabel,Predicted_Test_Labels_New);
Err_MultiNewSvm_Test  = 1 - sum(diag(NewSVMTest))/sum(NewSVMTest(:));





