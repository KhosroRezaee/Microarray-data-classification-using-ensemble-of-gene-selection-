

function [Err, out]=FeatureSelectionCost(c,Data,Label)


global gamma
global ci
global x1
global x2
global NumKfold

indices = crossvalind('kfold',Label,NumKfold);
for i = 1 : NumKfold
    
    test = (indices==i);
    train = ~test;
    
    % ------------------------------Data dividing---------------------------------
    TrainData = Data(train,:);
    TrainLabel = Label(train);
    TestData = Data(test,:);
    TestLabel = Label(test); 
    
    gamma(i) = c(1);
    ci(i) = abs(c(2));
    x1(i) = ceil(abs(c(3)));
    x2(i) = ceil(abs(c(4))); 
    
    Model = fitcsvm(TrainData,TrainLabel,'KernelFunction', 'rbf', 'KernelScale',...
    gamma(i), 'Standardize', true, 'BoxConstraint', ci(i)); 
    % ,'Cost',[0,x1(i);x2(i),0]
  
    [Predicted_Test_Labels_New] =  predict(Model,TestData); 
    NewSVMTest = confusionmat(TestLabel,Predicted_Test_Labels_New);
    E(i)  = 1 - sum(diag(NewSVMTest))/sum(NewSVMTest(:));      
end

%[Err,Address] = mean(E);
Err = mean(E);


    out.gamma=mean(gamma);
    out.ci= mean(ci);
    out.E=Err;
    %out.x1=mean(x1);
    %out.x2=mean(x2);

    
end