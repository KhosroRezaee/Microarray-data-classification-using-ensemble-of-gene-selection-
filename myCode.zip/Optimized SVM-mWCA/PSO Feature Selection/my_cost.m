function [E,z] = my_cost (c,Data,Target)

%load Info


global gamma
global ci

global x1
global x2
% s1=reshape(c(size(data,2)+1:2*size(data,2)),size(data,2),1);
% s=eye(size(data,2));
% s(s==1)=s1;

% m = abs(c(1));
% s = abs(c(2));
gamma =ceil(abs (c(1)));
    ci = ceil(abs(c(2)));
    x1 = ceil(abs(c(3)));
    x2 = ceil(abs(c(4)));
% Nuoo = (c(3)^2/(c(3)^2+1));
%p = (c(4)^2)/((c(4)^2)+1);

Model = fitcsvm(TrainData,TrainLabel,'KernelFunction', 'rbf', 'KernelScale',...
    gamma, 'Standardize', true, 'BoxConstraint', ci,'Cost',[0,x1;x2,0]);

%Model = fitcsvm(TrainData,TrainLabel,'KernelFunction','mhlbns','Cost',[0,x1;x2,0]);
[Predicted_Test_Labels_New] =  predict(Model,TestData);
NewSVMTest = confusionmat(TestLabel,Predicted_Test_Labels_New);
E  = 1 - sum(diag(NewSVMTest))/sum(NewSVMTest(:));

end