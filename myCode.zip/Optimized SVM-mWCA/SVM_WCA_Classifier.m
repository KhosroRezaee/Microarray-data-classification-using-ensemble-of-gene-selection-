

function [FinalTrAccuracy,FinalTeAccuracy,Acc_MultiNewSvm_Train,Acc_MultiNewSvm_Test] = ...
                                     SVM_WCA_Classifier(featuresVector,changeTargets,numCVKfoldClassification,maxIterationWCA)

clear gamma ci 
NumKfold = numCVKfoldClassification;
MaxGenerations=10;


% load Diabetes
% Input = Data;
% Label = Label+1;

Data = featuresVector;
Label = changeTargets;

% objective_function:           Objective function which you wish to minimize or maximize
objective_function=@my_cost;
% LB:                           Lower bound of a problem
LB=[.01,1,zeros(1,size(Data,2))];
% UB:                           Upper bound of a problem
UB=[10,10,ones(1,size(Data,2))];
% nvars:                        Number of design variables
nvars=size(Data,2)+2;
% Npop                          Population size
Npop=20;
% Nsr                           Number of rivers + sea
Nsr=5;
% dmax                          Evporation condition constant
dmax=1e-16;
% max_it:                       Maximum number of iterations
max_it = maxIterationWCA;


mindata = min(Data);
maxdata = max(Data);
Data = bsxfun(@rdivide,bsxfun(@minus, Data, mindata),maxdata - mindata);


indices = crossvalind('kfold',Label,NumKfold);
for i = 1 : NumKfold
    
    test = (indices==i);
    train = ~test;
    
    % ------------------------------Data dividing---------------------------------
    TrainData = Data(train,:);
    TrainLabel = Label(train);
    TestData = Data(test,:);
    TestLabel = Label(test);
    
    %MaxLab = max(unique([TrainLabel',TestLabel']));
   
    save ('Info','TrainData','TrainLabel')
    
    [Err,gamma,ci]= WCA(objective_function,LB,UB,nvars,Npop,Nsr,dmax,max_it);

    %[gamma,ci,validationErr] = WCA_Optimazation (TrainData,TrainLabel,MaxGenerations,PopulationSize);
    
    %gamma = (abs (c(1)));
    %ci = (abs(c(2)));
    %x1 = ceil(abs(c(3)));
    %x2 = ceil(abs(c(4)));

    Model = fitcsvm(TrainData,TrainLabel,'KernelFunction', 'rbf',...
        'KernelScale', gamma, 'Standardize', true, 'BoxConstraint', ci);
    % ,'Cost',[0,x1;x2,0]
    
    Predicted_Train_Labels_New  = predict(Model,TrainData);
    NewSVMTrain = confusionmat(TrainLabel,Predicted_Train_Labels_New);
    Acc_MultiNewSvm_Train(i)  = sum(diag(NewSVMTrain))/sum(NewSVMTrain(:));
    
    Predicted_Test_Labels_New =  predict(Model,TestData);
    NewSVMTest = confusionmat(TestLabel,Predicted_Test_Labels_New);
    Acc_MultiNewSvm_Test(i)  = sum(diag(NewSVMTest))/sum(NewSVMTest(:));
    gamma
    ci
    disp ('***************************************************************')
    disp(['The number of K-fold loop: ' num2str(i)])
    disp (['Acc-SVM-Train = ' num2str(Acc_MultiNewSvm_Train(i))])
    disp(['Acc-SVM-Test = ' num2str(Acc_MultiNewSvm_Test(i))])
    
end

FinalTrAccuracy = mean(Acc_MultiNewSvm_Train);
FinalTeAccuracy = mean(Acc_MultiNewSvm_Test);
end



