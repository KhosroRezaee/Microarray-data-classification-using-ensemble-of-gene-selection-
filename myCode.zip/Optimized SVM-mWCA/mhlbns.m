function D=mhlbns(X1,X2)
% m=ones(size(X1,2),1);
% s=eye(size(X1,2),size(X1,2));
global m
global s
D=zeros(size(X1,1),size(X2,1));
for i=1:size(X1,1)
    for j=size(X2,1)
        D(i,j)=(X1(i,:)'-m)'*s*(X2(j,:)'-m);
    end
end

end