function [result] = multisvm(TrainingSet,GroupTrain,TestSet,GAPar)

global gamma
global ci
global x1
global x2


gamma = abs(GAPar(1));
    ci = abs(GAPar(2));
    x1 = abs(GAPar(3));
    x2 = abs(GAPar(4));
    
% sigma0=10;
% error0=1e-10;
%Models a given training set with a corresponding group vector and
%classifies a given test set using an SVM classifier according to a
%one vs. all relation.


u=unique(GroupTrain);
numClasses=length(u);

result = zeros(length(TestSet(:,1)),1);

%build models
for k=1:numClasses
    %Vectorized statement that binarizes Group
    %where 1 is the current class and 0 is all other classes
%     disp(['build models',num2str(k)])
    G1vAll=(GroupTrain==u(k));
    models{k}  = fitcsvm(TrainingSet,G1vAll','KernelFunction','mhlbns','Cost',[0,x1;x2,0]);
end

%classify test cases
for j=1:size(TestSet,1)
    for k=1:numClasses
        if(predict(models{k},TestSet(j,:)))
            break;
        end
    end
        
    result(j) = k;
end

end