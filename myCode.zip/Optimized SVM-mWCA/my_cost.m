function [Err,gamma,ci] = my_cost(a)

load Info

Index = a(3:end)>0.5;

global gamma
global ci
global NumKfold

indices = crossvalind('kfold',TrainLabel,NumKfold);
for i = 1 : NumKfold
    
    test = (indices==i);
    train = ~test;
    
    % ------------------------------Data dividing---------------------------------
    newTrainData = TrainData(train,:);
    newTrainLabel = TrainLabel(train);
    validData = TrainData(test,:);
    validLabel = TrainLabel(test); 
    
    gamma(i) = a(1);
    ci(i) = abs(a(2));
    
    Model = fitcsvm(newTrainData,newTrainLabel,'KernelFunction', 'rbf', 'KernelScale',...
    gamma(i), 'Standardize', true, 'BoxConstraint', ci(i)); 
    % ,'Cost',[0,x1(i);x2(i),0]
  
    [Predicted_Test_Labels_New] =  predict(Model,validData); 
    NewSVMTest = confusionmat(validLabel,Predicted_Test_Labels_New);
    E(i)  = 1 - sum(diag(NewSVMTest))/sum(NewSVMTest(:));      
end

%[Err,Address] = mean(E);
Err = mean(E);
gamma = mean(gamma);
ci = mean(ci);
  
end

    
    
    
    
    