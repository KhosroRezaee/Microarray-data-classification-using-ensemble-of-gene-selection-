function G = mysigmoid(U,V)
% Sigmoid kernel function with slope gamma and intercept c
global gamma 
global ci
G = tanh(gamma*U*V' + ci);
end