   
function [finalNNAccuracy,finalSVMAccuracy,finalKNNAccuracy,finalDTAccuracy,finalNBAccuracy] = classificationModel(FeaturesVector,Label,NumKfold,numNN,featuresID) 

global minNumberFeatures
%% classification
    MatchingRaws = round(size(FeaturesVector,1)/NumKfold);
    indices = crossvalind('kfold',Label,NumKfold);
    
    for i = 1 : NumKfold   
        disp ('***************************************************************') 
        disp(['The number of k-Fold loop: ' num2str(i)]) 
        test = (indices==i);   
        train = ~test;  
        [TrainData,TrainLabel,TestData,TestLabel] = DividingData (FeaturesVector,Label,train,test,MatchingRaws);  
        
        [trainNNLabel(:,i),testNNLabel(:,i),trainAccuracyNN(i),testAccuracyNN(i)] = MLFFNNClassifier (TrainData,TrainLabel,TestData,TestLabel,numNN); 
        [trainSVMLabel(:,i),testSVMLabel(:,i),trainAccuracySVM(i),testAccuracySVM(i)] = SVMClassifier (TrainData,TrainLabel,TestData,TestLabel); 
        [trainDTLabel(:,i),testDTLabel(:,i),trainAccuracyDT(i),testAccuracyDT(i)] = DTClassifier (TrainData,TrainLabel,TestData,TestLabel); 
        [trainKnnLabel(:,i),testKnnLabel(:,i),trainAccuracyKnn(i),testAccuracyKnn(i)] = KNNClassifier (TrainData,TrainLabel,TestData,TestLabel);  
        [trainNBLabel(:,i),testNBLabel(:,i),trainAccuracyNB(i),testAccuracyNB(i)] = NBClassifier (TrainData,TrainLabel,TestData,TestLabel);
        
    end
   
        %% Final Results 
    disp('-------------------------------final results of k-fold cross validation---------------------------------') 
    finalNNAccuracy = mean(testAccuracyNN);
    finalSVMAccuracy = mean(testAccuracySVM);
    finalKNNAccuracy = mean(testAccuracyKnn);
    finalDTAccuracy = mean(testAccuracyDT); 
    finalNBAccuracy = mean(testAccuracyNB); 
    
    testLabel=testNNLabel;testAccuracy = testAccuracyNN;save('SixFeaturesBreast','minNumberFeatures','testAccuracy','testLabel','featuresID');

    
   figure
   forLegend = bplot([testAccuracyNN;testAccuracySVM;testAccuracyKnn;testAccuracyDT;testAccuracyNB]','outliers'); 
   grid on
   pause(0.1)
end


