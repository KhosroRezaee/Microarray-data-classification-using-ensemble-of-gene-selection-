
function [TrainAccuracy,TestAccuracy,ConMatTrain,ConMatTest,Predicted_Train_Labels,Predicted_Test_Labels] = BinaryClassification(NetWork,TrainData,TrainLabel,TestData,TestLabel)
    
    global Pestorior
    Predicted_Train_Labels = round(sim(NetWork,TrainData))';
    Predicted_Train_Labels(Predicted_Train_Labels>1.5)=2;
     Predicted_Train_Labels(Predicted_Train_Labels<1.5)=1;
    ConMatTrain = confusionmat(TrainLabel',Predicted_Train_Labels);
    TrainAccuracy = sum(diag(ConMatTrain))/sum(ConMatTrain(:));
        
    Predicted_Test_Labels = round(sim(NetWork,TestData))'; 
    Pestorior = sim(NetWork,TestData)';
    
    Predicted_Test_Labels(Predicted_Test_Labels>1.5)=2;
     Predicted_Test_Labels(Predicted_Test_Labels<1.5)=1;
    ConMatTest = confusionmat(TestLabel,Predicted_Test_Labels); 
    TestAccuracy = sum(diag(ConMatTest))/sum(ConMatTest(:));
end