

function FixedOutput = CreateFixedLabels(Predicted_Labels,MaxLab)
 

[m,n] = size(Predicted_Labels);
FixedOutput = zeros(m,n);
for i = 1:m
    for j = 1:n
        if  Predicted_Labels(i,j) >(MaxLab+0.51)
            FixedOutput(i,j) = MaxLab; 
        elseif  Predicted_Labels(i,j) < 1.5 
            FixedOutput(i,j) = 1; 
        elseif Predicted_Labels(i,j) > 1.5 & Predicted_Labels(i,j) < 2.5 
            FixedOutput(i,j) = 2; 
        elseif Predicted_Labels(i,j) > 2.5 & Predicted_Labels(i,j) < 3.5 
            FixedOutput(i,j) = 3; 
        elseif Predicted_Labels(i,j) > 3.5 & Predicted_Labels(i,j) < 4.5 
            FixedOutput(i,j) = 4; 
        elseif Predicted_Labels(i,j) > 4.5 & Predicted_Labels(i,j) < 5.5 
            FixedOutput(i,j) = 5; 
        elseif Predicted_Labels(i,j) > 5.5 & Predicted_Labels(i,j) < 6.5 
            FixedOutput(i,j) = 6; 
        elseif Predicted_Labels(i,j) > 6.5 & Predicted_Labels(i,j) < 7.5 
            FixedOutput(i,j) = 7; 
        elseif Predicted_Labels(i,j) > 7.5 & Predicted_Labels(i,j) < 8.5 
            FixedOutput(i,j) = 8; 
        elseif Predicted_Labels(i,j) > 8.5 & Predicted_Labels(i,j) < 9.5 
            FixedOutput(i,j) = 9; 
        elseif Predicted_Labels(i,j) > 9.5 & Predicted_Labels(i,j) < 10.5 
            FixedOutput(i,j) = 10; 
        end
    end
end
end

 
 