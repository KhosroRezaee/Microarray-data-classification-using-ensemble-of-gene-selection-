
function [trainDTLabel,testDTLabel,trainAccuracyDT,testAccuracyDT] = DTClassifier (TrainData,TrainLabel,TestData,TestLabel)

      DTModel = fitctree(TrainData,TrainLabel); 

        
         testDTLabel = predict(DTModel,TestData); 
         TestConfusionMatrix = confusionmat(TestLabel,testDTLabel); 
         testAccuracyDT =  sum(diag(TestConfusionMatrix))/sum(TestConfusionMatrix(:));

         trainDTLabel = predict(DTModel,TrainData); 
         TrainConfusionMatrix = confusionmat(TrainLabel,trainDTLabel); 
         trainAccuracyDT =  sum(diag(TrainConfusionMatrix))/sum(TrainConfusionMatrix(:));
         

end