
function [trainKnnLabel,testKnnLabel,trainAccuracyKnn,testAccuracyKnn] = KNNClassifier (TrainData,TrainLabel,TestData,TestLabel)

      KNNModel = fitcknn(TrainData,TrainLabel,'NumNeighbors',max(unique(TrainLabel))); 
     
         testKnnLabel = KNNModel.predict(TestData);  
         TestConfusionMatrix = confusionmat(TestLabel,testKnnLabel); 
         testAccuracyKnn = sum(diag(TestConfusionMatrix))/sum(TestConfusionMatrix(:));
        
         trainKnnLabel = KNNModel.predict(TrainData);  
         TrainConfusionMatrix = confusionmat(TrainLabel,trainKnnLabel); 
         trainAccuracyKnn = sum(diag(TrainConfusionMatrix))/sum(TrainConfusionMatrix(:));


end