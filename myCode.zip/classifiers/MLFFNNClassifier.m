
function [trainNNLabel,testNNLabel,trainAccuracy,testAccuracy] = MLFFNNClassifier (TrainData,TrainLabel,TestData,TestLabel,numNN)

    MaxLab = max(unique([TrainLabel;TestLabel]));
    NN = cell(1, numNN);
    TrAcc =  zeros(1, numNN);
    TeAcc =  zeros(1, numNN);
    
    for j = 1:numNN
         Alpha(j) = randi(10,1);
         Beta(j) = randi(5,1);
        % Net = newcf(TrainData',TrainLabel',Alpha(j),{Params.MLP.Fnc},'trainlm');
        Net = feedforwardnet([Alpha(j) Beta(j)]);
        Net.trainParam.showWindow = false;
        Net.trainParam.showCommandLine = false;
        
        NN{j} = train(Net,TrainData', TrainLabel'); 
        
        
        
            [NNTrainAccuracy{j},NNTestAccuracy{j},ConMatTrain{j},ConfusionMatrix{j},Predicted_Train_Labels{j},Predicted_Test_Labels{j}] = ...
                MulticlassClassification(NN{j},TrainData',TrainLabel',TestData',TestLabel');

    end

        [tsAcc,tsAddress] = max(cell2mat(NNTestAccuracy)); 
        testAccuracy = NNTestAccuracy{tsAddress}; 
        tsNNConfusionMatrix = ConfusionMatrix{tsAddress}; 
        testNNLabel = Predicted_Test_Labels{tsAddress}; 
        
        trainAccuracy = NNTrainAccuracy{tsAddress}; 
        trNNConfusionMatrix = ConMatTrain{tsAddress}; 
        trainNNLabel = Predicted_Train_Labels{tsAddress};   

    
    
   
end


