
function [TrainAccuracy,TestAccuracy,ConMatTrain,ConMatTest,FixedOutput_Train,FixedOutput_Test] =...
    MulticlassClassification(NetWork,TrainData,TrainLabel,TestData,TestLabel,MaxLab)
     
    MaxLab = max(unique([TrainLabel,TestLabel]));
    Predicted_Train_Labels = (sim(NetWork,TrainData))';
    FixedOutput_Train = CreateFixedLabels(Predicted_Train_Labels,MaxLab);
    ConMatTrain = confusionmat(TrainLabel,FixedOutput_Train);
    TrainAccuracy = sum(diag(ConMatTrain))/sum(ConMatTrain(:));
        
    Predicted_Test_Labels = (sim(NetWork,TestData))'; 
    FixedOutput_Test = CreateFixedLabels(Predicted_Test_Labels,MaxLab);
    ConMatTest = confusionmat(TestLabel,FixedOutput_Test); 
    TestAccuracy = sum(diag(ConMatTest))/sum(ConMatTest(:));
end