
function [trainNBLabel,testNBLabel,trainAccuracyNB,testAccuracyNB] = NBClassifier (TrainData,TrainLabel,TestData,TestLabel)

      NBModel = fitcnb(TrainData,TrainLabel); 

         testNBLabel = predict(NBModel,TestData); 
         TestConfusionMatrix = confusionmat(TestLabel,testNBLabel); 
         testAccuracyNB =  sum(diag(TestConfusionMatrix))/sum(TestConfusionMatrix(:));
        
         trainNBLabel = predict(NBModel,TrainData); 
         TrainConfusionMatrix = confusionmat(TrainLabel,trainNBLabel); 
         trainAccuracyNB =  sum(diag(TrainConfusionMatrix))/sum(TrainConfusionMatrix(:));

end