

function [trainSVMLabel,testSVMLabel,trainAccuracy,testAccuracy] = SVMClassifier (TrainData,TrainLabel,TestData,TestLabel)

     Model = fitcsvm(TrainData,TrainLabel,'Solver','L1QP','KernelFunction', 'polynomial','KernelScale','auto');
     

         testSVMLabel = predict(Model,TestData); 
         TestConfusionMatrix = confusionmat(TestLabel,testSVMLabel); 
         testAccuracy =  sum(diag(TestConfusionMatrix))/sum(TestConfusionMatrix(:));
        
         trainSVMLabel = predict(Model,TrainData); 
         TrainConfusionMatrix = confusionmat(TrainLabel,trainSVMLabel); 
         trainAccuracy =  sum(diag(TrainConfusionMatrix))/sum(TrainConfusionMatrix(:));
         

end