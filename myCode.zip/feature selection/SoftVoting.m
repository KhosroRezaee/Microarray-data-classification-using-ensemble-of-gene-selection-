function [Acc, WeightVotingLabel] = SoftVoting(predictions,vote_weights,TestLabel)
final_votes = [];
for c = 1:length(predictions)
    votes = [];
    weights = [];
    
    for m = 1:length(vote_weights)
        %m
        found = -1;
        if(m == 1)
            votes = [votes, predictions(c,m)];
            weights = [weights, vote_weights(m)];
        end
        votecounts = numel(votes);
        for idx = 1:votecounts
            if (votes(idx) == predictions(c,m))
                found = idx;
                weights(found) = weights(found) + vote_weights(m);
            end
            if((idx == numel(votes)) && (found == -1))
                found = idx+1;
                votes = [votes, predictions(c,m)];
                weights = [weights, vote_weights(m)];
            end  
        end
    end
    [val1, idx1] = max(weights);
    final_votes = [final_votes, votes(idx1)];   
end
VotingLabel = final_votes';

    m = size(TestLabel,1);
    for p = 1 : m
        CandidLabel(p,:) = mode(predictions(p,:));
    end

    VotingConfusionMatrix1 = confusionmat(TestLabel,VotingLabel); 
    Accuracy1 = sum(diag(VotingConfusionMatrix1))/sum(VotingConfusionMatrix1(:));
    VotingConfusionMatrix2 = confusionmat(TestLabel,CandidLabel); 
    Accuracy2 = sum(diag(VotingConfusionMatrix2))/sum(VotingConfusionMatrix2(:));
    
    if Accuracy2>Accuracy1
        WeightVotingLabel = CandidLabel;
        Acc = Accuracy2;
    else
        WeightVotingLabel = VotingLabel;
        Acc = Accuracy1;
    end
    
end




