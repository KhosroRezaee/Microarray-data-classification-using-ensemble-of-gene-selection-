
function [Ind] = featureSelectionEnsembling(data,labels,kFold,numOfSelectedFeatures)


 k=5; % Number of nearest neighbor
 [sFeatRelief,SfRe,NfRe]=jRF(data,labels,k,numOfSelectedFeatures);
 
 [sFeatPCC,SfPCC,NfPCC]=jPCC(data,labels,numOfSelectedFeatures);
 
 [sFeatFSc,SfFSc,NfFSc]=jFS(data,labels,numOfSelectedFeatures);
 
 [sFeatTV,SfTV,NfTV]=jTV(data,numOfSelectedFeatures);
 
 EIndex = [SfRe(1:numOfSelectedFeatures);SfPCC;SfFSc;SfTV];
 [uniqueValues,~,uniqueIndex] = unique(EIndex);
 frequency = accumarray(uniqueIndex(:),1)./numel(EIndex);
 [sorted, indices] = sort(frequency,'descend');
 GoldFeaturesIndex = uniqueValues(indices)';
 %Selected_Features = data(:,GoldFeaturesIndex(1,1:NumOfGoldFeat));
 Ind = GoldFeaturesIndex(1,1:numOfSelectedFeatures);
 
end