
function Acc=jKNN(feat,label,k,kfold)
rng('default'); 
% Perform k-nearest neighbor classifier with Euclidean distance
Model=fitcknn(feat,label,'NumNeighbors',k,'Distance','euclidean');
% Perform cross-validation
C=crossval(Model,'KFold',kfold);
% Accuracy for each fold
Afold=100*(1-kfoldLoss(C,'mode','individual'));
% Average accuracy
Acc=mean(Afold); 
end


