
function [sFeat,Sf,Nf]=jPCC(feat,label,nFeat)

% Mean of features & labels
Xmu=mean(feat,1); Ymu=mean(label,1); 
% Substract Mean from features & labels
dX=feat-Xmu; dY=label-Ymu;
% Numerator 
nume=sum((dX.*dY),1);
% Denominator
deno=sqrt(sum(dX.^2,1).*sum(dY.^2,1));
% Pearson Correlation Coefficient 
pcc=nume./deno; 
% Absolute PCC 
pcc=abs(pcc);
% Sort PCC from high to low
[~,Sf]=sort(pcc,'descend');
% Select features based on selected index 
Sf=Sf(1:nFeat); sFeat=feat(:,Sf); Nf=length(Sf);
end


