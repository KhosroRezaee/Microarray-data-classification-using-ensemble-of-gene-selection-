

function [sFeat,Sf,Nf]=jRF(feat,label,k,nFeat)
%---Input------------------------------------------------------------------
% feat:  feature vector (instances x features)
% label: labelling 
% nFeat: Pre-determined number of selected features
%---Output-----------------------------------------------------------------
% sFeat: Selected features (instances x features)
% Sf:    Selected feature index
% Nf:    Number of selected features
%--------------------------------------------------------------------------

% Convert format to categorical
label=categorical(label); 
% Relief-F Algorithm
Sf=relieff(feat,label,k);
% Select features based on ranking
sFeat=feat(:,Sf(1:nFeat)); Nf=length(Sf); 
sFeat=feat(:,Sf);
end

