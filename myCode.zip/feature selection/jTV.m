
function [sFeat,Sf,Nf]=jTV(feat,nFeat)
%---Input------------------------------------------------------------------
% feat:  feature vector (instances x features)
% nFeat: Pre-determined number of selected features
%---Output-----------------------------------------------------------------
% sFeat: Selected features (instances x features)
% Sf:    Selected feature index
% Nf:    Number of selected features
%--------------------------------------------------------------------------

% Number of instances and features 
[I,D]=size(feat);
% Pre
TermVariance=zeros(1,D); 
for d=1:D
  % Mean of each dth feature
  mu=mean(feat(:,d));
  % Term variance 
  TermVariance(d)=(1/I)*sum((feat(:,d)-repmat(mu,I,1)).^2);
end
% Larger value offer better information
[~,Sf]=sort(TermVariance,'descend');
% Select features based on selected index 
Sf=Sf(1:nFeat); sFeat=feat(:,Sf); Nf=length(Sf);
end

