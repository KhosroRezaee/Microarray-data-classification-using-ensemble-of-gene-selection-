

clc; clear; close all; warning off

%-------------------------------------Necessary pathes--------------------------------------
%restoredefaultpath
CurrentPath = pwd;
addpath (genpath(CurrentPath))
global minNumberFeatures

DataIdx = input('Please select your input data (ProstateTumorData=1, LeukemiaData=2, DLBCLData=3, ColonCancer=4, BreastCancer=5): ');

switch DataIdx
    case 1
        disp('Prostate Tumor data is loaded...')
        load ProstateTumorData
        labels = Labels+1;
    case 2
       disp('Leukemia data is loaded...')
        load LeukemiaData  
        labels = Labels+1;
    case 3
       disp('DLBCL data is loaded...')
        load DLBCLData   
        labels = Labels+1;
    case 4
        disp('Colon cancer data is loaded...')
        load ColonCancer
        labels = Labels;
    case 5
        disp('Breast cancer data is loaded...')
        load BreastCancer 
        labels = Labels;
end

features=Features;
% mindata = min(Input);
% maxdata = max(Input);
% features = bsxfun(@rdivide,bsxfun(@minus, Input, mindata),maxdata - mindata);

minNumberFeatures = 3;
maxNumberFeatures = 14;
Iteration = 5;
numCVKfoldFS = 10;
numCVKfoldClassification = 10;
maxIterationWCA = 20;
counter = 0;

%% Data mixing
randomLocations = randperm(numel(labels));
changeTargets = labels(randomLocations); % A 1-D list at this point
changeData = features(randomLocations,:);

for numOfSelectedFeatures = minNumberFeatures:1:maxNumberFeatures % As on num 
    
    for i = 1:Iteration 
        disp(['The number of iteration loop is: ' num2str(i)]) 
        [ensembleFeatures{i}] = featureSelectionEnsembling(changeData,changeTargets,numCVKfoldFS,numOfSelectedFeatures); 
    end
   
   counter = counter + 1;
   selectedFeaturesIndex = cell2mat(ensembleFeatures); 
   [uniqueValues,~,uniqueIndex] = unique(selectedFeaturesIndex);
   frequency = accumarray(uniqueIndex(:),1)./numel(selectedFeaturesIndex);
   [sorted, indices] = sort(frequency,'descend');
   GoldFeaturesIndex = uniqueValues(indices)';
   %Selected_Features = data(:,GoldFeaturesIndex(1,1:NumOfGoldFeat));
   Ind{counter} = GoldFeaturesIndex(1:numOfSelectedFeatures)';
   featuresID = Ind{counter};
   featuresVector = changeData(:,Ind{counter});
   [FinalTrAccuracy,FinalTeAccuracy,Acc_MultiNewSvm_Train,Acc_MultiNewSvm_Test] = ...
                                     SVM_WCA_Classifier(featuresVector,changeTargets,numCVKfoldClassification,maxIterationWCA);
    
end


% save('ProstateResults','nnAccuracy','knnAccuracy','dtAccuracy','nbAccuracy','Ind')
% 
% figure
% hAx(1) = axes(); 
% hold on; hLine(1) = plot(nnAccuracy,'-bs','LineWidth',1);
% hold on; hLine(2) = plot(svmAccuracy,'--gs','LineWidth',1);
% hold on; hLine(3) = plot(knnAccuracy,'-.rs','LineWidth',1);
% hold on; hLine(4) = plot(dtAccuracy,'-b*','LineWidth',1);
% hold on; hLine(5) = plot(nbAccuracy,'-ko','LineWidth',1);
% set(0,'DefaultAxesFontName', 'Times New Roman'); grid on;
% legend([hLine(1), hLine(2),hLine(3), hLine(4),hLine(5)],{'NN' 'SVM','k-NN' 'DT','NB'},'Location','SouthWest', 'Color','w')





