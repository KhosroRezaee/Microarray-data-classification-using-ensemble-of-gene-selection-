
function [TrainData,TrainLabel,TestData,TestLabel] = DividingData (Data,Label,train,test,MatchinRaws)

    TrainData = Data(train,:);
    TrainLabel = Label(train);
    TestData = Data(test,:);
    TestLabel = Label(test);
    
    b = size(TestData,1); 
    
    if MatchinRaws > b
        TestData = [TestData;TrainData(end,:)];
        TestLabel = [TestLabel;TrainLabel(end,:)];
        TrainData = TrainData(1:end-1,:);
        TrainLabel = TrainLabel(1:end-1,:);
    elseif MatchinRaws < b
        TrainData = [TrainData;TestData(end,:)];
        TrainLabel = [TrainLabel;TestLabel(end,:)];
        TestData = TestData(1:end-1,:);
        TestLabel = TestLabel(1:end-1,:);
    else
        TrainData = Data(train,:); 
        TrainLabel = Label(train); 
        TestData = Data(test,:); 
        TestLabel = Label(test);
    end
    
end